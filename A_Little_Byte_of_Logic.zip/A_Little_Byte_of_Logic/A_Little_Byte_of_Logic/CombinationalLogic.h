#pragma once
#include "CircuitElement.h"

class CombinationalLogic : public CircuitElement {
	//virtual function that each element defines
	//number of inputs
};