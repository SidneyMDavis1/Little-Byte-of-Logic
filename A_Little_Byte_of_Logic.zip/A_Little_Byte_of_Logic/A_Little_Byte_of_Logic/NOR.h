#pragma once
#include "CombinationalLogic.h"

class NOR : public CombinationalLogic {
	//define the virtual function with functionality
	//
};