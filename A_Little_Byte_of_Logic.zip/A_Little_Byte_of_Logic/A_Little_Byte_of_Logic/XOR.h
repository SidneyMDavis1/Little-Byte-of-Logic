#pragma once
#include "CombinationalLogic.h"

class XOR: public CombinationalLogic {
	//define the virtual function with functionality
	//
};