#pragma once
#include "CombinationalLogic.h"

class NOT : public CombinationalLogic {
	//define the virtual function with functionality
	//
};