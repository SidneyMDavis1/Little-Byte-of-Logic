#pragma once

class CircuitElement {
//an abstract class with a propogation delay for every element
};