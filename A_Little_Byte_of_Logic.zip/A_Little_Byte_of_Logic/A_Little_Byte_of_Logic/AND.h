#pragma once
#include "CombinationalLogic.h"

class AND : public CombinationalLogic{
	//define the virtual function with functionality
	//
};