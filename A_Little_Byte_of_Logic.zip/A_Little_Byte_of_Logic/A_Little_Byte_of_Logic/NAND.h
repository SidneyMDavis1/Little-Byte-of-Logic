#pragma once
#include "CombinationalLogic.h"

class NAND : public CombinationalLogic {
	//define the virtual function with functionality
	//
};