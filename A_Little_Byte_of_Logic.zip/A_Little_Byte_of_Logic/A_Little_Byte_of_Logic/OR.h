#pragma once
#include "CombinationalLogic.h"

class OR : public CombinationalLogic {
	//define the virtual function with functionality
	//
};