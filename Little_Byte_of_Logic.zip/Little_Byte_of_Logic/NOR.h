#pragma once

#include "Headers/CombinationalLogic.h"

class NOR : public CombinationalLogic
{
private:

public:
	virtual void instantiate(unsigned int x, unsigned int y);
	virtual void update_output(void);
};