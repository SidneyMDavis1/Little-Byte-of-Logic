#ifndef WIRE_H
#define WIRE_H

class Wire
{
private:

protected:

public:

};

#endif
