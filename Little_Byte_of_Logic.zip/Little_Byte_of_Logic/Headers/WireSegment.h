#ifndef WIRE_SEGMENT_H
#define WIRE_SEGMENT_H

class WireSegment 
{
private:

public:

};

#endif
