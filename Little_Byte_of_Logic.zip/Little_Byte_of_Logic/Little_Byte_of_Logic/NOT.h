#ifndef NOT_H
#define NOT_H

#include "..\CombinationalLogic.h"

class NOT : public CombinationalLogic
{
private:

public:
	virtual void instantiate(unsigned int x, unsigned int y);
	virtual void update_output(void);
};

#endif
