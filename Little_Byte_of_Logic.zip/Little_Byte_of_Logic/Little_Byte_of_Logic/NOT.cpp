#include "..\..\Headers\CL_classes\NOT.h"

void NOT::instantiate(unsigned int x, unsigned int y)
{

}

void NOT::update_output(void)
{
	for (int i = 0; i < input_pins; i++)
	{

	}
}