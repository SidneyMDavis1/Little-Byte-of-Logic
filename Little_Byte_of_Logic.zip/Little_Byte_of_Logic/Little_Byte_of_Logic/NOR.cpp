#include "..\..\Headers\CL_classes\NOR.h"

void NOR::instantiate(unsigned int x, unsigned int y)
{

}

void NOR::update_output(void)
{
	for (int i = 0; i < input_pins; i++)
	{

	}
}