#include "..\..\Headers\CL_classes\OR.h"

void OR::instantiate(unsigned int x, unsigned int y)
{

}

void OR::update_output(void)
{
	for (int i = 0; i < input_pins; i++)
	{

	}
}