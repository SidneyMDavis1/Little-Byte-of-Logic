#ifndef OR_H
#define OR_H

#include "..\CombinationalLogic.h"

class OR : public CombinationalLogic
{
private:

public:
	virtual void instantiate(unsigned int x, unsigned int y);
	virtual void update_output(void);
};

#endif
