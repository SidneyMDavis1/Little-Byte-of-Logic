#include "..\..\Headers\CL_classes\AND.h"

void AND::instantiate(unsigned int x, unsigned int y)
{

}

void AND::update_output(void)
{
	for (int i = 0; i < input_pins; i++) 
	{

	}
}
