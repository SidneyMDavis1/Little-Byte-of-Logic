#ifndef NAND_H
#define NAND_H

#include "..\CombinationalLogic.h"

class NAND : public CombinationalLogic
{
private:

public:
	virtual void instantiate(unsigned int x, unsigned int y);
	virtual void update_output(void);
};

#endif