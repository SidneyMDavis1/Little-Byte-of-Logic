#include "..\..\Headers\CL_classes\NAND.h"

void NAND::instantiate(unsigned int x, unsigned int y)
{

}

void NAND::update_output(void)
{
	for (int i = 0; i < input_pins; i++)
	{

	}
}