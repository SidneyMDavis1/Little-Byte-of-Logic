#include "..\..\Headers\CL_classes\XOR.h"

void XOR::instantiate(unsigned int x, unsigned int y)
{

}

void XOR::update_output(void)
{
	for (int i = 0; i < input_pins; i++)
	{

	}
}