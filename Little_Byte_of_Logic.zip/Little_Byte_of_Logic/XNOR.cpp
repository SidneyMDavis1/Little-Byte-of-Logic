#include "XNOR.h"

void XNOR::instantiate(unsigned int x, unsigned int y)
{
	set_coord(x, y);
}

void XNOR::update_output(void)
{
	for (int i = 0; i < input_pins; i++)
	{

	}
}
