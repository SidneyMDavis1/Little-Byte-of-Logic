#include "NAND.h"

void NAND::instantiate(unsigned int x, unsigned int y)
{
	set_coord(x, y);
}

void NAND::update_output(void)
{
	for (int i = 0; i < input_pins; i++)
	{

	}
}